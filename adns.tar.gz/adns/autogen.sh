#!/bin/sh
set -e
autoheader
autoconf
